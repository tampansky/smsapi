# -*- coding: utf-8 -*-

name = 'smsapi-client'
version = '2.3.0'

lib_info = '%s/%s' % (name, version)