# -*- coding: utf-8 -*-


class Api(object):

    def __init__(self, api_client):
        super(Api, self).__init__()

        self.client = api_client
