# -*- coding: utf-8 -*-

default_response = 'json'

response_format_param = {'format': default_response}